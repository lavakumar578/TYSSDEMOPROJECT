package com.tyss.demo.util;
/**
 * This class is used to get the path of the file
 * @author LAVA KUMAR
 *
 */
public interface ILocation {

	String PROPERTYPATH="./src/test/resources/commonData.properties";
	String EXCELPATH="./src/test/resources/testData.xlsx";
	
}
